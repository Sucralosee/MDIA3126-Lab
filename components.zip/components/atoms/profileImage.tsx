import { Text, View } from "react-native";

export default function ProfileImage() {
    return(
        <View>
            <img src="MinerPika.jpg" 
                style={{
                    width: "10rem",
                }}
            />        
        </View>
    ) 
}