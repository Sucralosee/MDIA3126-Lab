import { Text, View } from "react-native";

export default function SingleLine( {SingleLineText}) { 
    return(
        <View>
            <Text
                style={{
                    color:"red"
                }}
            >
                {SingleLineText}    
            </Text>
        </View>
    ) 
}